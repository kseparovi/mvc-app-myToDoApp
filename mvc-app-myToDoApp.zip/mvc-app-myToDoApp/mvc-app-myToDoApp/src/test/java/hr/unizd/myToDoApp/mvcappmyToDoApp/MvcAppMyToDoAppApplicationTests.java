package hr.unizd.myToDoApp.mvcappmyToDoApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcAppMyToDoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
